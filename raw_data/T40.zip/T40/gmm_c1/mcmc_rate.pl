
#use Statistics::Descriptive;

my $file = $ARGV[0];
open IN,"<","$file";
while (<IN>)
{
	chomp;
	if (/^r_(g\d+)_(n\d+)/)
	{
		my @tmp = split(/\s+/,$_);
		push @{$1}, $tmp[1];
		$hash{$1}=1;
	}
}
close IN;

foreach my $key (sort keys %hash)
{
	$sum = 0;
	foreach my $ele (@{$key})
	{
		$sum+=$ele;
	}
	$mean = $sum/($#{$key}+1);
	print "$key\t$mean\n";
}

#r_g28_n402
