# run RCCalculator
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0000
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0001
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0002
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0003
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0004
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0005
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0006
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0007
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0008
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0009
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0010
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0011
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0012
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0013
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0014
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0015
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0016
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0017
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0018
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0019
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0020
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0021
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0022
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0023
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0024
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0025
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0026
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0027
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0028
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0029
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0030
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0031
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0032
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0033
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0034
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0035
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0036
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0037
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0038
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0039
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0040
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0041
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0042
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0043
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0044
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0045
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0046
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0047
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0048
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0049
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0050
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0051
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0052
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0053
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0054
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0055
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0056
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0057
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0058
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0059
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0060
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0061
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0062
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0063
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0064
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0065
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0066
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON3v3_codon/pt0067
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0000
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0001
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0002
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0003
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0004
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0005
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0006
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0007
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0008
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0009
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0010
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0011
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0012
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0013
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0014
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0015
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0016
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0017
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0018
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0019
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0020
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0021
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0022
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0023
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0024
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0025
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0026
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0027
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0028
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0029
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0030
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0031
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0032
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0033
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0034
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0035
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0036
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0037
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0038
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0039
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0040
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0041
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0042
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0043
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0044
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0045
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0046
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0047
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0048
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0049
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0050
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0051
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0052
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0053
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0054
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0055
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0056
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0057
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0058
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0059
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0060
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0061
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0062
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0063
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0064
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0065
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0066
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON2v4_aa/pt0067
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0000
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0001
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0002
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0003
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0004
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0005
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0006
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0007
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0008
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0009
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0010
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0011
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0012
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0013
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0014
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0015
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0016
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0017
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0018
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0019
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0020
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0021
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0022
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0023
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0024
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0025
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0026
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0027
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0028
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0029
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0030
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0031
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0032
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0033
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0034
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0035
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0036
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0037
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0038
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0039
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0040
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0041
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0042
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0043
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0044
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0045
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0046
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0047
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0048
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0049
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0050
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0051
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0052
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0053
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0054
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0055
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0056
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0057
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0058
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0059
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0060
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0061
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0062
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0063
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0064
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0065
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0066
sbatch -n1 ./run_HON.lsf
cd /share/home-user/hzhang/Proch_sup/Proch_dRdC_SAG_basal/drdc_cal/dRdC_dat/HON0_zhang/pt0067
sbatch -n1 ./run_HON.lsf
