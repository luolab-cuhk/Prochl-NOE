#!/bin/bash

mcmctree mcmctree.p2.ctl > log
