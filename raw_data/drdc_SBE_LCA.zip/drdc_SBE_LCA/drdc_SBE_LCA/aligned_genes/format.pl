my $file = $ARGV[0];
open IN,"<","$file";
while (<IN>)
{
	if (/>(\S+)$/)
	{
		my $seq = <IN>;
		if ($seq=~/N/)
		{
			next;
		}
		else
		{
			print ">$1\n$seq";
		}
	}
}
close IN;


